export const baseUrl = "https://collectionapi.metmuseum.org";
